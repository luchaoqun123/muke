import { Controller, Get, Param, OnModuleInit } from '@nestjs/common';
import { UserService } from './user.service';

@Controller('users')
export class UserController implements OnModuleInit {
  constructor(private readonly userService: UserService) {
    console.log('UserController constructor');
  }

  onModuleInit() {
    console.log('onModuleInit UserController', this.userService);
  }

  @Get('/:userId')
  async getUser(@Param('userId') userId) {
    return await this.userService.findOne(userId);
  }
}
