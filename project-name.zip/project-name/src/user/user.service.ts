import { Injectable } from '@nestjs/common';
//line 3,7,10 如果注释就会走onModuleInit，反之就不会
// 实际开发中，我是要使用到OperationLogsService 的
// import { OperationLogsService } from '../operation-logs/operation-logs.service';

@Injectable()
export class UserService {
  // constructor(private operationLog: OperationLogsService) {}

  async findOne(userId: string): Promise<any> {
    // this.operationLog.add('user', { userId });
    console.log(userId);
    return { hah: '1' };
  }
}
