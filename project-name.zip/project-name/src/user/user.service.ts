import { Injectable } from '@nestjs/common';
//line 3,7,10 如果不注释就不会走onModuleInit
// import { OperationLogsService } from '../operation-logs/operation-logs.service';

@Injectable()
export class UserService {
  // constructor(private operationLog: OperationLogsService) {}

  async findOne(userId: string): Promise<any> {
    // this.operationLog.add('user', { userId });
    console.log(userId);
    return { hah: '1' };
  }
}
