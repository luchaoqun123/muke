import { Module, OnModuleInit, Global } from '@nestjs/common';
import { UserController } from './user.controller';
import { UserService } from './user.service';

@Global()
@Module({
  controllers: [UserController],
  providers: [UserService],
  exports: [UserService],
})
// export class UserModule {}
export class UserModule implements OnModuleInit {
  constructor(private userService: UserService) {
    console.log('onModuleInit UserModule constructor');
  }

  onModuleInit() {
    console.log('onModuleInit UserModule', this.userService);
  }
}
