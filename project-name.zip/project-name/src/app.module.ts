import { Module } from '@nestjs/common';
import { UserModule } from './user/user.module';
import { OperationLogsModule } from './operation-logs/operation-logs.module';

@Module({
  imports: [UserModule, OperationLogsModule],
})
export class AppModule {}
