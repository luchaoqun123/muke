import { Injectable, Inject } from '@nestjs/common';
import { REQUEST } from '@nestjs/core';
import { Request } from 'express';

@Injectable()
export class OperationLogsService {
  constructor(@Inject(REQUEST) private readonly request: Request) {}

  async find(conditions: object): Promise<{ total: number; results: any[] }> {
    const data = { total: 0, results: [] };

    const userIds = [];

    const condition = { ...conditions };
    delete condition['username'];
    if (userIds && userIds.length > 0) {
      condition['userId'] = {
        $in: userIds.map((e) => {
          return e.userId;
        }),
      };
    }
    data.total = 10;
    data.results = [];
    return data;
  }

  private logData(module: string, action: string) {
    const data: any = { module, action };
    data.userId = (this.request as any).user.userId || '';
    data.route = this.request.url;
    data.ip = '';
    return data;
  }

  private saveLog(module: string, data: object, action: string) {
    const logData = this.logData(module, action);
    const log = { module, ...logData, diffDetail: data };
    console.log(log);
  }

  add(module: string, data: object | []) {
    this.saveLog(module, { added: data }, 'add');
  }

  update(module: string, data: object | []) {
    this.saveLog(module, data, 'update');
  }

  delete(module: string, data?: object | []) {
    this.saveLog(module, { deleted: data }, 'delete');
  }
}
