import { Module, Global, OnModuleInit } from '@nestjs/common';
import { OperationLogsController } from './operation-logs.controller';
import { OperationLogsService } from './operation-logs.service';

@Global()
@Module({
  imports: [],
  controllers: [OperationLogsController],
  providers: [OperationLogsService],
  exports: [OperationLogsService],
})
// export class OperationLogsModule {}
export class OperationLogsModule implements OnModuleInit {
  constructor(private logService: OperationLogsService) {
    console.log('onModuleInit OperationLogsModule constructor');
  }

  onModuleInit() {
    console.log('onModuleInit OperationLogsModule', this.logService);
  }
}
