import { Controller, Get, Query, HttpStatus } from '@nestjs/common';
import { OperationLogsService } from './operation-logs.service';
import {
  ApiOperation,
  ApiResponse,
  ApiTags,
  ApiQuery,
  ApiHeader,
} from '@nestjs/swagger';

@Controller('operation-logs')
export class OperationLogsController {
  constructor(private operationLogService: OperationLogsService) {}

  @ApiHeader({
    name: 'authorization',
    required: true,
    description: '本次请求请带上token',
  })
  @ApiTags('操作记录')
  @ApiOperation({
    summary: '获取用户操作记录',
  })
  @ApiResponse({
    status: HttpStatus.OK,
  })
  @ApiQuery({ name: 'module', description: '操作的模块', required: false })
  @ApiQuery({
    name: 'action',
    description: '操作的类型，删除，更新等',
    required: false,
  })
  @ApiQuery({
    name: 'ip',
    description: '操作者的ip',
    required: false,
  })
  @ApiQuery({
    name: 'username',
    description: '操作用户的名字',
    required: false,
  })
  @ApiQuery({
    name: 'scenicId',
    description: '景区Id',
    required: false,
  })
  @ApiQuery({
    name: 'scenicSpotId',
    description: '景点Id',
    required: false,
  })
  @ApiQuery({
    name: 'pageSize',
    description: '每页数量，默认10',
    required: false,
  })
  @ApiQuery({ name: 'page', description: '页数，默认1', required: false })
  @Get('')
  index(@Query() query) {
    const conditions = {};
    let limit = 10;
    let skip = 0;
    if (query) {
      if (query.username) {
        const regex = new RegExp(query.username, 'i');
        conditions['username'] = { $regex: regex };
      }
      if (query.ip) {
        const regex = new RegExp(query.ip, 'i');
        conditions['ip'] = { $regex: regex };
      }
      if (query.action) {
        conditions['action'] = query.action;
      }
      if (query.module) {
        conditions['module'] = query.module;
      }
      if (query.scenicId) {
        const regex = new RegExp(query.scenicId, 'i');
        conditions['route'] = { $regex: regex };
      }
      if (query.scenicSpotId) {
        const regex = new RegExp(query.scenicSpotId, 'i');
        conditions['route'] = { $regex: regex };
      }
      limit = Number(query.pageSize) || 10;
      const pageNumber = Number(query.page) || 1;
      skip = ((pageNumber > 1 ? pageNumber : 1) - 1) * limit;
    }
    console.log(skip);
    return this.operationLogService.find(conditions);
  }
}
